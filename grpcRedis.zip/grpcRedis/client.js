var PROTO_PATH = __dirname + '/grpc.proto';
var parseArgs = require('minimist');
var grpc = require('@grpc/grpc-js');
var protoLoader = require('@grpc/proto-loader');
var packageDefinition = protoLoader.loadSync(
    PROTO_PATH,
    {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true
    });
var grpc_proto = grpc.loadPackageDefinition(packageDefinition).grpcserv;
var client = new grpc_proto.grpcServ('localhost:5000', grpc.credentials.createInsecure());


/* //CHANNEL TARGET MUST BE A STRING 
var argv = parseArgs(process.argv.slice(2), {
  string: 'target'
});
var target;
if (argv.target) {
  target = argv.target;
} else {
  target = 'localhost:5000';
}
*/


let keyParam = "user2"
client.Get({ key: keyParam }, function (err, response) {   
  console.log("KEY: ", keyParam, "VALUE: ", response.resp);
});

