const { RedisConnector } = require("./RedisConnector.js");
var PROTO_PATH = __dirname + '/grpc.proto';
var grpc = require('@grpc/grpc-js');
var protoLoader = require('@grpc/proto-loader');
var packageDefinition = protoLoader.loadSync(
    PROTO_PATH,
    {keepCase: true,
     longs: String,
     enums: String,
     defaults: true,
     oneofs: true
    });
var grpc_proto = grpc.loadPackageDefinition(packageDefinition).grpcserv;

function main() {
  var server = new grpc.Server();
  server.addService(grpc_proto.grpcServ.service, { Get: Get });
  server.bindAsync("127.0.0.1:5000", grpc.ServerCredentials.createInsecure(), (err) => {
    server.start();
    console.log("GRPC Server 5000 üzerinde başlatıldı.....");
  });
}
main();


//redis bağlantısı
const conn = new RedisConnector();
async function Get(call, callback) {
   callback(null, {
    resp: await conn.getJSONFile(call.request.key)
  });
}